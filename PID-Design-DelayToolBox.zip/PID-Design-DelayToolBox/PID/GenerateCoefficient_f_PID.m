function strRootf = GenerateCoefficient_f_PID(hn,hd);
syms lambda;
Hn=poly2sym(hn,lambda);
Hd=poly2sym(hd,lambda);
syms kp ki kd real;
f=Hd*lambda+Hn*(ki+kp*lambda+kd*lambda^2);
coef= poly_coeffs(f,'lambda');
coef = fliplr(coef);
n=length(coef);

%fid = fopen('Rootf_GeneratedFunction_PID.m','wt');
%fprintf(fid,'function lambdaroot=Rootf_GeneratedFunction_PID(kp,ki,kd)\n');
%fprintf(fid,'lambdaroot=roots([');
strRootf = '            lambdaroot=roots([';
for i=1:1:n
    coefroot=coef(1,i);
    coefroot=char(coefroot);
    str = sprintf('(%s)\t',coefroot);
    strRootf = [strRootf str];
end
%fprintf(fid,']);\n');
str = ']);';
strRootf = [strRootf str];
%fprintf(fid,'end\n');
%fclose(fid);
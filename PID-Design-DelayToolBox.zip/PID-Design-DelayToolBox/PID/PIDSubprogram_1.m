function PIDSubprogram(kp1,ki1,kd1,size,MaxDelayRange,sigma_precisionbound,checkboxesinputvector)

figure('NumberTitle', 'off', 'Name', 'Stability Set');

MaxnumberofStabilityIntervals=0;
MaxDelayMargin=0;
MaxGeneralizedDelayMargin=0;
xxx=[];yyy=[];zzz=[];vvv=[];
xxxx=[];yyyy=[];zzzz=[];vvvv=[];
MaxDelayMargin_kp=[];
MaxDelayMargin_ki=[];
MaxDelayMargin_kd=[];
MaxGeneralizedDelayMargin_kp=[];
MaxGeneralizedDelayMargin_ki=[];
MaxGeneralizedDelayMargin_kd=[];


for kp=kp1
    for ki=ki1
        for kd=kd1
            if( kp==0 && ki==0 && kd==0)
                continue;
            end
            
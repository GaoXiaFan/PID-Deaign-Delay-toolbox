function Init_PID(hn,hd)
%�����ĸ������ļ�
strRootf = GenerateCoefficient_f_PID(hn,hd);
p1 = mfilename('fullpath');%%�������н����˵��õ��ļ�������·�������ƣ��������ļ���չ����%%
location=strfind(p1,'\');%%��p1����������%%
p1=p1(1:location(end));
cd(p1);%%������һ��Ŀ¼%%
fidin1=fopen('PIDSubprogram_2.m','w+');
fprintf(fidin1,'%s',strRootf);
fclose(fidin1);

strRootFW = GenerateCoefficient_FW_PID(hn,hd);
fidin1=fopen('PIDSubprogram_4.m','w+');
fprintf(fidin1,'%s',strRootFW);
fclose(fidin1);

[strHn,strHd] = GenerateHnHd_PID(hn,hd);
fidin1=fopen('PIDSubprogram_6.m','w+');
fprintf(fidin1,'%s',strHn);
fclose(fidin1);

fidin1=fopen('PIDSubprogram_7.m','w+');
fprintf(fidin1,'%s',strHd);
fclose(fidin1);

%1-24��
fidin1=fopen('PIDSubprogram_1.m','r+');
LineNumber=0;
newtline = [];
while ~feof(fidin1)
    tline=fgetl(fidin1);
    LineNumber=LineNumber+1;
    newtline{LineNumber}=tline;                                                                                                                                                                                                           
end
fclose(fidin1);

%25��
fidin1=fopen('PIDSubprogram_2.m','r+');%strRootf
while ~feof(fidin1)
    tline=fgetl(fidin1);
    LineNumber=LineNumber+1;
    newtline{LineNumber}=tline;                                                                                                                                                                                                         
end
fclose(fidin1);

%26-41��
fidin1=fopen('PIDSubprogram_3.m','r+');
while ~feof(fidin1)
    tline=fgetl(fidin1);
    LineNumber=LineNumber+1;
    newtline{LineNumber}=tline;                                                                                                                                                                                                         
end
fclose(fidin1);

%42��
fidin1=fopen('PIDSubprogram_4.m','r+');%strRootFW
while ~feof(fidin1)
    tline=fgetl(fidin1);
    LineNumber=LineNumber+1;
    newtline{LineNumber}=tline;
end
fclose(fidin1);

%43-63��
fidin1=fopen('PIDSubprogram_5.m','r+');
while ~feof(fidin1)
    tline=fgetl(fidin1);
    LineNumber=LineNumber+1;
    newtline{LineNumber}=tline;  
end
fclose(fidin1);

%64��
fidin1=fopen('PIDSubprogram_6.m','r+');%strHn
while ~feof(fidin1)
    tline=fgetl(fidin1);
    LineNumber=LineNumber+1;
    newtline{LineNumber}=tline;
end
fclose(fidin1);

%65��
fidin1=fopen('PIDSubprogram_7.m','r+');%strHd
while ~feof(fidin1)
    tline=fgetl(fidin1);
    LineNumber=LineNumber+1;
    newtline{LineNumber}=tline;
end
fclose(fidin1);

%66-146��
fidin1=fopen('PIDSubprogram_8.m','r+');
while ~feof(fidin1)
    tline=fgetl(fidin1);
    LineNumber=LineNumber+1;
    newtline{LineNumber}=tline;
end
fclose(fidin1);


%������д����ʽ�򿪣�д�븲��ԭ��������
fidin1=fopen('PIDSubprogram.m','w+');
for j=1:1:LineNumber
    fprintf(fidin1,'%s\r\n',newtline{j});
end
fclose(fidin1);
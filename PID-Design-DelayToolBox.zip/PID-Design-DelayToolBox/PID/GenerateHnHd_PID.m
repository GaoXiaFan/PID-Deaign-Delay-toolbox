function [strHn,strHd] = GenerateHnHd_PID(hn,hd);
syms lambda;
Hn=poly2sym(hn,lambda);
Hd=poly2sym(hd,lambda);
Hn=char(Hn);
Hd=char(Hd);

%fid = fopen('Hn_GeneratedFunction_PID.m','wt');
%fprintf(fid,'function Hn=Hn_GeneratedFunction_PID(lambda)\n');
%fprintf(fid,'Hn=');
%fprintf(fid,'%s;\n',Hn);
%fprintf(fid,'end\n');
%fclose(fid);
str = ';';
strHn = '                            Hn=';
strHn = [strHn Hn];
strHn = [strHn str];

% fid = fopen('Hd_GeneratedFunction_PID.m','wt');
% fprintf(fid,'function Hd=Hd_GeneratedFunction_PID(lambda)\n');
% fprintf(fid,'Hd=');
% fprintf(fid,'%s;\n',Hd);
% fprintf(fid,'end\n');
% fclose(fid);
strHd = '                            Hd=';
strHd = [strHd Hd];
strHd = [strHd str];
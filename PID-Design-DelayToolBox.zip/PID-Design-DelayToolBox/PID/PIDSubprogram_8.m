                            z=-(Hd*lambda)/(Hn*(ki+kp*lambda+kd*lambda^2));
                            criticalw=omega;
                            criticalZ=z;
                            angZ=angle(criticalZ);
                            if angZ<=0
                                tau0=-1*angZ/criticalw;
                                period=2*pi/criticalw;
                            end
                            if angZ>0
                                tau0=(2*pi-angZ)/criticalw; 
                                period=2*pi/criticalw;
                            end
                            if (-1)^t==-1
                                CDsandPeriodsandDelta=[CDsandPeriodsandDelta,[tau0;period;2]];
                            else
                                CDsandPeriodsandDelta=[CDsandPeriodsandDelta,[tau0;period;-2]];
                            end
                        end
                        [numberofStablilityIntervals, leftends, rightends]=FindingStabilityIntervals(CDsandPeriodsandDelta,numberofeffectiveWroots,NUDelayFree,MaxDelayRange);
                        if numberofStablilityIntervals>0
                            if NUDelayFree==0
                                xxx=[xxx,kp];yyy=[yyy,ki];zzz=[zzz,kd];
                                vvv=[vvv,rightends(1,1)];
                                if rightends(1,1)>MaxDelayMargin
                                    MaxDelayMargin=rightends(1,1);
                                    MaxDelayMargin_kp=kp;
                                    MaxDelayMargin_ki=ki;
                                    MaxDelayMargin_kd=kd;
                                end
                            end
                            xxxx=[xxxx,kp];yyyy=[yyyy,ki];zzzz=[zzzz,kd];
                            vvvv=[vvvv,rightends(1,numberofStablilityIntervals)];
                            if numberofStablilityIntervals>MaxnumberofStabilityIntervals
                                MaxnumberofStabilityIntervals=numberofStablilityIntervals;
                            end
                            if rightends(1,numberofStablilityIntervals)>MaxGeneralizedDelayMargin
                                MaxGeneralizedDelayMargin=rightends(1,numberofStablilityIntervals);
                                MaxGeneralizedDelayMargin_kp=kp; 
                                MaxGeneralizedDelayMargin_ki=ki;
                                MaxGeneralizedDelayMargin_kd=kd;
                            end
                        end
                    end
                end
            end
     
    end
end


% scatter3(xxx,yyy,zzz,30,vvv,'filled');
scatter3(xxxx,yyyy,zzzz,size,vvvv,'filled');

fprintf('Results of stability analysis by ''PID-Design-Delay''Toolbox:\n')
switch checkboxesinputvector(1)
    case 1
        fprintf('\t\t Maximal number of stability delay-intervals is %d.\n',MaxnumberofStabilityIntervals)
end
switch checkboxesinputvector(2)
    case 1
        fprintf('\t\t Maximal delay margin is %f.\n',MaxDelayMargin)
end
switch checkboxesinputvector(3)
    case 1
        fprintf('\t\t Maximal delay margin is found at (kp=%f,ki=%f,kd=%f).\n',MaxDelayMargin_kp,MaxDelayMargin_ki,MaxDelayMargin_kd)
end
switch checkboxesinputvector(4)
    case 1
        fprintf('\t\t Maximal generalized delay margin is %f.\n',MaxGeneralizedDelayMargin)
end
switch checkboxesinputvector(5)
    case 1
        fprintf('\t\t Maximal generalized delay margin is found at (kp=%f,ki=%f,kd=%f).\n',MaxGeneralizedDelayMargin_kp,MaxGeneralizedDelayMargin_ki,MaxGeneralizedDelayMargin_kd)
end
fprintf('\t\t For stability set, please see Figure ''Stability Set''.\n')
set(gcf,'Position',[50 200 500 400])
title('Stability set in (k_P, k_I, k_D, \tau)-space')
view(69.6000,55.6000)
xlabel('k_P')
ylabel('k_I')
zlabel('k_D')
colorbar
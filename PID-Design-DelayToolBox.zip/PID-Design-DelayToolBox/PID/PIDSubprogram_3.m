            sigma=min(abs(real(lambdaroot)));
           
            numberoflambdaroots=length(lambdaroot);
            for d=1:1:numberoflambdaroots
            Reallambdaroot(d,1)=real(lambdaroot(d,1));
            end
        
           
                if norm(sigma)>=sigma_precisionbound
                    NUDelayFree=0; 
                    for d=1:1:numberoflambdaroots
                        if Reallambdaroot(d,1)>0
                            NUDelayFree=NUDelayFree+1;
                        end
                    end
                    
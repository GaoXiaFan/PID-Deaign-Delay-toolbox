function varargout = OptionsDocument_PID(varargin)
% OPTIONSDOCUMENT_PID MATLAB code for OptionsDocument_PID.fig
%      OPTIONSDOCUMENT_PID, by itself, creates a new OPTIONSDOCUMENT_PID or raises the existing
%      singleton*.
%
%      H = OPTIONSDOCUMENT_PID returns the handle to a new OPTIONSDOCUMENT_PID or the handle to
%      the existing singleton*.
%
%      OPTIONSDOCUMENT_PID('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in OPTIONSDOCUMENT_PID.M with the given input arguments.
%
%      OPTIONSDOCUMENT_PID('Property','Value',...) creates a new OPTIONSDOCUMENT_PID or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before OptionsDocument_PID_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to OptionsDocument_PID_OpeningFcn via varargin.
%
%      *See GUI OptionsDocument_PID on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help OptionsDocument_PID

% Last Modified by GUIDE v2.5 01-Jul-2020 15:58:12

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @OptionsDocument_PID_OpeningFcn, ...
                   'gui_OutputFcn',  @OptionsDocument_PID_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before OptionsDocument_PID is made visible.
function OptionsDocument_PID_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to OptionsDocument_PID (see VARARGIN)

% Choose default command line output for OptionsDocument_PID
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
global sigma_precisionbound
global checkbox_1_input
global checkbox_2_input
global checkbox_3_input
global checkbox_4_input
global checkbox_5_input
global pointsize
text('Interpreter','latex',...
           'String','($$k_P$$, $$k_I$$, $$k_D$$) at which the maximal generalized delay margin is found',...
           'Position',[-.04 .62],...
           'FontSize',11)
text('Interpreter','latex',...
           'String','maximal generalized delay margin',...
           'Position',[-.04 .71],...
           'FontSize',11)
text('Interpreter','latex',...
           'String','($$k_P$$, $$k_I$$, $$k_D$$) at which the maximal delay margin is found',...
           'Position',[-.04 .8],...
           'FontSize',11)
text('Interpreter','latex',...
           'String','maximal delay margin',...
           'Position',[-.04 .89],...
           'FontSize',11)     
 text('Interpreter','latex',...
           'String','maximal number of stability delay-intervals',...
           'Position',[-.04 .975],...
           'FontSize',11)             
text('Interpreter','latex',...
           'String','$$\widetilde\sigma$$',...
           'Position',[0.21 0.43],...
           'FontSize',14)
text('Interpreter','latex',...
           'String','size of points',...
           'Position',[0.13 0.25],...
           'FontSize',12)   
axis off
try
    set(handles.sigmaprecisionbound_gui,'String',num2str(sigma_precisionbound))
    set(handles.NumberofStabilityIntervals_gui,'value',checkbox_1_input)
    set(handles.MaxDelayMargin_gui,'value',checkbox_2_input)
    set(handles.MaxDelayMargin_kpandki_gui,'value',checkbox_3_input)
    set(handles.MaxGeneralizedDelayMargin_gui,'value',checkbox_4_input)
    set(handles.MaxGeneralizedDelayMargin_kpandki_gui,'value',checkbox_5_input)
    set(handles.pointsize_gui,'value',pointsize)
catch
   sigma_precisionbound=str2num(get(handles.sigmaprecisionbound_gui,'String'));
    checkbox_1_input=get(handles.NumberofStabilityIntervals_gui,'value');
    checkbox_2_input=get(handles.MaxDelayMargin_gui,'value');
    checkbox_3_input=get(handles.MaxDelayMargin_kpandki_gui,'value');
    checkbox_4_input=get(handles.MaxGeneralizedDelayMargin_gui,'value');
    checkbox_5_input=get(handles.MaxGeneralizedDelayMargin_kpandki_gui,'value');
    pointsize=get(handles.pointsize_gui,'value');
end
movegui( gcf, 'center' )
% UIWAIT makes OptionsDocument_PID wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = OptionsDocument_PID_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sigmaprecisionbound_gui_Callback(hObject, eventdata, handles)
% hObject    handle to sigmaprecisionbound_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sigmaprecisionbound_gui as text
%        str2double(get(hObject,'String')) returns contents of sigmaprecisionbound_gui as a double


% --- Executes during object creation, after setting all properties.
function sigmaprecisionbound_gui_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sigmaprecisionbound_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in print_gui.
function print_gui_Callback(hObject, eventdata, handles)
% hObject    handle to print_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns print_gui contents as cell array
%        contents{get(hObject,'Value')} returns selected item from print_gui


% --- Executes during object creation, after setting all properties.
function print_gui_CreateFcn(hObject, eventdata, handles)
% hObject    handle to print_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in pointsize_gui.
function pointsize_gui_Callback(hObject, eventdata, handles)
% hObject    handle to pointsize_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns pointsize_gui contents as cell array
%        contents{get(hObject,'Value')} returns selected item from pointsize_gui


% --- Executes during object creation, after setting all properties.
function pointsize_gui_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pointsize_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in for_Apply.
function for_Apply_Callback(hObject, eventdata, handles)
% hObject    handle to for_Apply (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global sigma_precisionbound
global checkbox_1_input
global checkbox_2_input
global checkbox_3_input
global checkbox_4_input
global checkbox_5_input
global pointsize
sigma_precisionbound=str2num(get(handles.sigmaprecisionbound_gui,'String'));
checkbox_1_input=get(handles.NumberofStabilityIntervals_gui,'value');
checkbox_2_input=get(handles.MaxDelayMargin_gui,'value');
checkbox_3_input=get(handles.MaxDelayMargin_kpandki_gui,'value');
checkbox_4_input=get(handles.MaxGeneralizedDelayMargin_gui,'value');
checkbox_5_input=get(handles.MaxGeneralizedDelayMargin_kpandki_gui,'value');
pointsize=get(handles.pointsize_gui,'value');
close


% --- Executes on button press in NumberofStabilityIntervals_gui.
function NumberofStabilityIntervals_gui_Callback(hObject, eventdata, handles)
% hObject    handle to NumberofStabilityIntervals_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of NumberofStabilityIntervals_gui


% --- Executes on button press in MaxDelayMargin_gui.
function MaxDelayMargin_gui_Callback(hObject, eventdata, handles)
% hObject    handle to MaxDelayMargin_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of MaxDelayMargin_gui


% --- Executes on button press in MaxGeneralizedDelayMargin_gui.
function MaxGeneralizedDelayMargin_gui_Callback(hObject, eventdata, handles)
% hObject    handle to MaxGeneralizedDelayMargin_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of MaxGeneralizedDelayMargin_gui


% --- Executes on button press in MaxGeneralizedDelayMargin_kpandki_gui.
function MaxGeneralizedDelayMargin_kpandki_gui_Callback(hObject, eventdata, handles)
% hObject    handle to MaxGeneralizedDelayMargin_kpandki_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of MaxGeneralizedDelayMargin_kpandki_gui


% --- Executes on button press in MaxDelayMargin_kpandki_gui.
function MaxDelayMargin_kpandki_gui_Callback(hObject, eventdata, handles)
% hObject    handle to MaxDelayMargin_kpandki_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of MaxDelayMargin_kpandki_gui


% --- Executes on button press in for_Default.
function for_Default_Callback(hObject, eventdata, handles)
% hObject    handle to for_Default (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
RestoreDefault_PID

function strRootFW = GenerateCoefficient_FW_PID(hn,hd)
syms kp ki kd w real;
syms lambda;
Hn=poly2sym(hn,lambda);
Hd=poly2sym(hd,lambda);
Hn=subs(Hn,lambda,1i*w);
Hd=subs(Hd,lambda,1i*w);
F=(real(Hd*1i*w))^2+(imag(Hd*1i*w))^2-(real(Hn*(ki+kp*1i*w-kd*w^2)))^2-(imag(Hn*(ki+kp*1i*w-kd*w^2)))^2;
F=collect(F);
coeFw=poly_coeffs(F,'w');
coeFW=coeFw(1:2:end);
coeFW = fliplr(coeFW);
n=length(coeFW);

%fid = fopen('RootFW_GeneratedFunction_PID.m','wt');
%fprintf(fid,'function Wroot=RootFW_GeneratedFunction_PID(kp,ki,kd)\n');
%fprintf(fid,'Wroot=roots([');
strRootFW = '                    Wroot=roots([';
for i=1:1:n
    coeFWroot=coeFW(1,i);
    coeFWroot=char(coeFWroot);
    str = sprintf('(%s)\t',coeFWroot);   
    strRootFW = [strRootFW str];
end
%fprintf(fid,']);\n');
str = ']);';
strRootFW = [strRootFW str];
%fprintf(fid,'end\n');
%fclose(fid);
function PDSubprogram(kp1,kd1,hn,hd,line,col,MaxDelayRange,sigma_precisionbound,checkboxesinputvector)

figure('NumberTitle', 'off', 'Name', 'Stability Set');
hold on

MaxnumberofStabilityIntervals=0;
MaxDelayMargin=0;
MaxGeneralizedDelayMargin=0;
MaxDelayMargin_kp=[];
MaxStableDelaykd_delaymargin=[];
MaxGeneralizedDelayMargin_kp=[];
MaxGeneralizedDelayMargin_kd=[];


for   kp=kp1
    for kd=kd1
        if( kp==0 && kd==0)
            continue;
        end
        
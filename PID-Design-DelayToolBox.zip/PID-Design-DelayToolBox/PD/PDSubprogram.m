function PDSubprogram(kp1,kd1,hn,hd,line,col,MaxDelayRange,sigma_precisionbound,checkboxesinputvector)

figure('NumberTitle', 'off', 'Name', 'Stability Set');
hold on

MaxnumberofStabilityIntervals=0;
MaxDelayMargin=0;
MaxGeneralizedDelayMargin=0;
MaxDelayMargin_kp=[];
MaxStableDelaykd_delaymargin=[];
MaxGeneralizedDelayMargin_kp=[];
MaxGeneralizedDelayMargin_kd=[];


for   kp=kp1
    for kd=kd1
        if( kp==0 && kd==0)
            continue;
        end
        
        lambdaroot=roots([(8*kd + 1)	(kd + 8*kp + 76629/10000)	(10*kd + kp + 3573/2500)	(kd + 10*kp + 46629/5000)	(kd + kp + 1073/2500)	(kp + 6629/10000)	]);
        sigma=min(abs(real(lambdaroot)));
        
        numberoflambdaroots=length(lambdaroot);
        for d=1:1:numberoflambdaroots
        Reallambdaroot(d,1)=real(lambdaroot(d,1));
        end
        
    
            if norm(sigma)>=sigma_precisionbound
                NUDelayFree=0; 
                for d=1:1:numberoflambdaroots
                if Reallambdaroot(d,1)>0
                    NUDelayFree=NUDelayFree+1;
                end
                end
              
                Wroot=roots([(1 - 64*kd^2)	(16*kd*(10*kd + kp) - (kd + 8*kp)^2 + 5586163641/100000000)	(2*(kd + 8*kp)*(kd + 10*kp) - 16*kd*(kd + kp) - (10*kd + kp)^2 - 140024333/1000000)	(2*(kd + kp)*(10*kd + kp) - 2*kp*(kd + 8*kp) - (kd + 10*kp)^2 + 4795159659/50000000)	(2*kp*(kd + 10*kp) - (kd + kp)^2 - 12179933/1000000)	(43943641/100000000 - kp^2)	]);
                numberofWroots=length(Wroot);
                numberofeffectiveWroots=0;
                effectiveW=[];

                for  s=1:1:numberofWroots
                    if imag(Wroot(s,1))==0
                        if Wroot(s,1)>0
                            numberofeffectiveWroots=numberofeffectiveWroots+1;
                            effectiveW(numberofeffectiveWroots,1)=Wroot(s,1);
                        end
                    end
                end
                if numberofeffectiveWroots>=1
                    effectiveW=sort(effectiveW,'descend');
                    CDsandPeriodsandDelta=[];     
                    
                    for t=1:1:numberofeffectiveWroots
                        omega=(effectiveW(t,1))^0.5; 
                        lambda=1i*omega;
                       
                        Hn=lambda + 10*lambda^2 + lambda^3 + 8*lambda^4 + 1;
                        Hd=(1073*lambda)/2500 + (46629*lambda^2)/5000 + (3573*lambda^3)/2500 + (76629*lambda^4)/10000 + lambda^5 + 6629/10000;
                        z=-Hd/(Hn*(kp+kd*lambda));
                        criticalw=omega;
                        criticalZ=z;
                        angZ=angle(criticalZ);
                        if angZ<=0
                            tau0=-1*angZ/criticalw;
                            period=2*pi/criticalw;
                        end
                        if angZ>0
                            tau0=(2*pi-angZ)/criticalw; 
                            period=2*pi/criticalw;
                        end
                        if (-1)^t==-1
                            CDsandPeriodsandDelta=[CDsandPeriodsandDelta,[tau0;period;2]];
                        else
                            CDsandPeriodsandDelta=[CDsandPeriodsandDelta,[tau0;period;-2]];
                        end
                    end
                    [numberofStablilityIntervals, leftends, rightends]=FindingStabilityIntervals(CDsandPeriodsandDelta,numberofeffectiveWroots,NUDelayFree,MaxDelayRange);
                    if numberofStablilityIntervals>0
                        if NUDelayFree == 0
                            if rightends(1,1)>MaxDelayMargin
                                MaxDelayMargin=rightends(1,1);
                                MaxDelayMargin_kp=kp;
                               MaxDelayMargin_kd=kd; 
                            end
                        end
                        if numberofStablilityIntervals>MaxnumberofStabilityIntervals
                            MaxnumberofStabilityIntervals=numberofStablilityIntervals;
                        end
                        if rightends(1,numberofStablilityIntervals)>MaxGeneralizedDelayMargin
                            MaxGeneralizedDelayMargin=rightends(1,numberofStablilityIntervals);
                                MaxGeneralizedDelayMargin_kp=kp; 
                                MaxGeneralizedDelayMargin_kd=kd;
                        end
                        for i=1:1:numberofStablilityIntervals
                            plot3([kp kp],[kd kd],[leftends(1,i) rightends(1,i)],'color',col,'LineWidth',line)
                        end
                    end
                end
            end
    
    end
end

fprintf('Results of stability analysis by ''PID-Design-Delay''Toolbox:\n')
switch checkboxesinputvector(1)
    case 1
        fprintf('\t\t Maximal number of stability delay-intervals is %d.\n',MaxnumberofStabilityIntervals)
end
switch checkboxesinputvector(2)
    case 1
        fprintf('\t\t Maximal delay margin is %f.\n',MaxDelayMargin)
end
switch checkboxesinputvector(3)
    case 1
        fprintf('\t\t Maximal delay margin is found at (kp=%f,kd=%f).\n',MaxDelayMargin_kp,MaxDelayMargin_kd)
end
switch checkboxesinputvector(4)
    case 1
        fprintf('\t\t Maximal generalized delay margin is %f.\n',MaxGeneralizedDelayMargin)
end

switch checkboxesinputvector(5)
    case 1
        fprintf('\t\t Maximal generalized delay margin is found at (kp=%f,kd=%f).\n',MaxGeneralizedDelayMargin_kp,MaxGeneralizedDelayMargin_kd)
end
fprintf('\t\t For stability set, please see Figure ''Stability Set''.\n')
set(gcf,'Position',[50 200 500 400])
title('Stability set in (k_P, k_D, \tau)-space')
view(-168.8000,20.4000)
xlabel('k_P')
ylabel('k_D')
zlabel('\tau')

                numberofWroots=length(Wroot);
                numberofeffectiveWroots=0;
                effectiveW=[];

                for  s=1:1:numberofWroots
                    if imag(Wroot(s,1))==0
                        if Wroot(s,1)>0
                            numberofeffectiveWroots=numberofeffectiveWroots+1;
                            effectiveW(numberofeffectiveWroots,1)=Wroot(s,1);
                        end
                    end
                end
                if numberofeffectiveWroots>=1
                    effectiveW=sort(effectiveW,'descend');
                    CDsandPeriodsandDelta=[];     
                    
                    for t=1:1:numberofeffectiveWroots
                        omega=(effectiveW(t,1))^0.5; 
                        lambda=1i*omega;
                       
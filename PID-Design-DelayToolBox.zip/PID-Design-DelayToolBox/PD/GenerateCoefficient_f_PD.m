function strRootf = GenerateCoefficient_f_PD(hn,hd)
syms lambda;
Hn=poly2sym(hn,lambda);
Hd=poly2sym(hd,lambda);
syms kp kd real;
f=Hd+Hn*(kd*lambda+kp);
coef= poly_coeffs(f,'lambda');
coef = fliplr(coef);
n=length(coef);

strRootf = '        lambdaroot=roots([';
for i=1:1:n
    coefroot=coef(1,i);
    coefroot=char(coefroot);
    str = sprintf('(%s)\t',coefroot);
    strRootf = [strRootf str];
end

str = ']);';
strRootf = [strRootf str];
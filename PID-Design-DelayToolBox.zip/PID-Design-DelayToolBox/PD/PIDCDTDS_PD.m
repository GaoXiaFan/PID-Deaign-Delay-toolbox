function varargout = PIDCDTDS_PD(varargin)
% PIDCDTDS_PD MATLAB code for PIDCDTDS_PD.fig
%      PIDCDTDS_PD, by itself, creates a new PIDCDTDS_PD or raises the existing
%      singleton*.
%
%      H = PIDCDTDS_PD returns the handle to a new PIDCDTDS_PD or the handle to
%      the existing singleton*.
%
%      PIDCDTDS_PD('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PIDCDTDS_PD.M with the given input arguments.
%
%      PIDCDTDS_PD('Property','Value',...) creates a new PIDCDTDS_PD or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before PIDCDTDS_PD_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to PIDCDTDS_PD_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help PIDCDTDS_PD

% Last Modified by GUIDE v2.5 09-Feb-2020 14:44:30

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @PIDCDTDS_PD_OpeningFcn, ...
                   'gui_OutputFcn',  @PIDCDTDS_PD_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before PIDCDTDS_PD is made visible.
function PIDCDTDS_PD_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to PIDCDTDS_PD (see VARARGIN)

% Choose default command line output for PIDCDTDS_PD
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

global linewidth
global col
global sigma_precisionbound
global checkbox_1_input
global checkbox_2_input
global checkbox_3_input
global checkbox_4_input
global checkbox_5_input
linewidth=5;
col=[0 0 0];
sigma_precisionbound=1e-8;
checkbox_1_input=1;
checkbox_2_input=0;
checkbox_3_input=0;
checkbox_4_input=1;
checkbox_5_input=0;
text('Interpreter','latex',...
           'String','Stability analysis in ($$k_P$$, $$k_D$$, $$\tau$$)-space',...
           'Position',[.01 .95],...
           'FontSize',11)
text('Interpreter','latex',...
           'String','$$H_N$$',...
           'Position',[.1 0.76],...
           'FontSize',12)
text('Interpreter','latex',...
           'String','$$H_D$$',...
           'Position',[.1 0.64],...
           'FontSize',12)
text('Interpreter','latex',...
           'String','$$k_P$$',...
           'Position',[.1 .53],...
           'FontSize',13)
text('Interpreter','latex',...
           'String','$$k_D$$',...
           'Position',[.1 .415],...
           'FontSize',13)
text('Interpreter','latex',...
           'String','$$\tau_{max}$$',...
           'Position',[.1 .31],...
           'FontSize',13)
   axis off
   movegui( gcf, 'center' )


% UIWAIT makes PIDCDTDS_PD wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = PIDCDTDS_PD_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function kp_gui_Callback(hObject, eventdata, handles)
% hObject    handle to kp_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of kp_gui as text
%        str2double(get(hObject,'String')) returns contents of kp_gui as a double


% --- Executes during object creation, after setting all properties.
function kp_gui_CreateFcn(hObject, eventdata, handles)
% hObject    handle to kp_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function kd_gui_Callback(hObject, eventdata, handles)
% hObject    handle to kd_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of kd_gui as text
%        str2double(get(hObject,'String')) returns contents of kd_gui as a double


% --- Executes during object creation, after setting all properties.
function kd_gui_CreateFcn(hObject, eventdata, handles)
% hObject    handle to kd_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function hn_gui_Callback(hObject, eventdata, handles)
% hObject    handle to hn_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of hn_gui as text
%        str2double(get(hObject,'String')) returns contents of hn_gui as a double


% --- Executes during object creation, after setting all properties.
function hn_gui_CreateFcn(hObject, eventdata, handles)
% hObject    handle to hn_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function hd_gui_Callback(hObject, eventdata, handles)
% hObject    handle to hd_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of hd_gui as text
%        str2double(get(hObject,'String')) returns contents of hd_gui as a double


% --- Executes during object creation, after setting all properties.
function hd_gui_CreateFcn(hObject, eventdata, handles)
% hObject    handle to hd_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function MaxDelayRange_gui_Callback(hObject, eventdata, handles)
% hObject    handle to MaxDelayRange_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of MaxDelayRange_gui as text
%        str2double(get(hObject,'String')) returns contents of MaxDelayRange_gui as a double


% --- Executes during object creation, after setting all properties.
function MaxDelayRange_gui_CreateFcn(hObject, eventdata, handles)
% hObject    handle to MaxDelayRange_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in start_gui.
function start_gui_Callback(hObject, eventdata, handles)
% hObject    handle to start_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clear PDSubprogram
fprintf('Running PID-Design-Delay...\n')
global linewidth
global col
global sigma_precisionbound
global checkbox_1_input
global checkbox_2_input
global checkbox_3_input
global checkbox_4_input
global checkbox_5_input
checkboxesinputvector=[checkbox_1_input checkbox_2_input checkbox_3_input checkbox_4_input checkbox_5_input];
% Get data from the interface
hn=str2num(get(handles.hn_gui,'String'));
hd=str2num(get(handles.hd_gui,'String'));
kp1=str2num(get(handles.kp_gui,'String'));
kd1=str2num(get(handles.kd_gui,'String'));
MaxDelayRange=str2num(get(handles.MaxDelayRange_gui,'String'));

if isempty(hn) || isempty(hd) || isempty(kp1) || isempty(kd1) || isempty(MaxDelayRange)
    fprintf(2,'Please fill all the edit boxes.\n');
    return;
end

% Set line width
switch linewidth
    case 1
        line=0.5;
    case 2
         line=1;
    case 3
         line=2;
    case 4
         line=3;
    case 5
         line=4;
    case 6
         line=5;
    case 7
         line=6;
end


Hndegree=length(hn);
Hddegree=length(hd);

if Hddegree<(Hndegree+1)
    fprintf(2,'The closed-loop system cannot be asymptotically stable, as it is of advanced type.\n');
else if Hddegree==(Hndegree+1)
        kdmax=abs(hd(1)/hn(1));
        kdmin=-kdmax;
        if (kd1(end) >= kdmax) || (kd1(1) <= kdmin)
            fprintf(2,'The closed-loop system is of neutral type and a necessary stability condition is: kd belongs to ��%f, %f��.\n',kdmin,kdmax);
        else
            Init_PD(hn,hd);
            PDSubprogram(kp1,kd1,hn,hd,line,col,MaxDelayRange,sigma_precisionbound,checkboxesinputvector);
        end
    else
        Init_PD(hn,hd);
        PDSubprogram(kp1,kd1,hn,hd,line,col,MaxDelayRange,sigma_precisionbound,checkboxesinputvector);
    end
end




% --------------------------------------------------------------------
function for_File_Callback(hObject, eventdata, handles)
% hObject    handle to for_File (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function for_Open_Callback(hObject, eventdata, handles)
% hObject    handle to for_Open (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% warning('off')
[filename,filepath,FilterIndex]=uigetfile('*.mat','Open');
file = [filepath filename];
if FilterIndex==0
    return
else
    load(file, 'hn','hd','kp1','kd1','MaxDelayRange')
end
try
    set(handles.hn_gui,'String',num2str(hn));
    set(handles.hd_gui,'String',num2str(hd));
    set(handles.kp_gui,'String',num2str(kp1));
    set(handles.kd_gui,'String',num2str(kd1));
    set(handles.MaxDelayRange_gui,'String',num2str(MaxDelayRange));
catch
      fprintf(2,'The opened information may be inappropriate.\n');
end

% --------------------------------------------------------------------
function for_Save_Callback(hObject, eventdata, handles)
% hObject    handle to for_Save (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
hn=str2num(get(handles.hn_gui,'String'));
hd=str2num(get(handles.hd_gui,'String'));
kp1=str2num(get(handles.kp_gui,'String'));
kd1=str2num(get(handles.kd_gui,'String'));
MaxDelayRange=str2num(get(handles.MaxDelayRange_gui,'String'));
[filename ,pathname,FilterIndex]=uiputfile({'*.mat','MAT-files(*.mat)'},'Save');
if FilterIndex==0
    return
else
    str=strcat(pathname,filename);
    save(char(str), 'hn','hd','kp1','kd1','MaxDelayRange')
end


% --------------------------------------------------------------------
function for_Exit_Callback(hObject, eventdata, handles)
% hObject    handle to for_Exit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close

% --------------------------------------------------------------------
function for_LastData_Callback(hObject, eventdata, handles)
% hObject    handle to for_Open (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function for_Demo_Callback(hObject, eventdata, handles)
% hObject    handle to for_Demo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function for_Demo1_Callback(hObject, eventdata, handles)
% hObject    handle to for_Demo1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --------------------------------------------------------------------
function for_Demo2_Callback(hObject, eventdata, handles)
% hObject    handle to for_Demo2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function for_Demo3_Callback(hObject, eventdata, handles)
% hObject    handle to for_Demo3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --------------------------------------------------------------------
function for_Options_Callback(hObject, eventdata, handles)
% hObject    handle to for_Options (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
OptionsDocument_PD


% --------------------------------------------------------------------
function for_help_Callback(hObject, eventdata, handles)
% hObject    handle to for_help (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Help_PD
% set(helpdocument_PDEdition, 'position', get(0,'ScreenSize'));


% --- Executes during object creation, after setting all properties.
function start_gui_CreateFcn(hObject, eventdata, handles)
% hObject    handle to start_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
s=sprintf('Please note that for a controlled plant, the\ncomplexity of analysis is proportional to the\nrange of each controller gain and inversely \n proportional to the step length. It is\n recommended to start the analysis with a \n relatively low complexity and then increase\n the complexity gradually. ');
set(hObject,'TooltipString',s);


% --------------------------------------------------------------------
function for_Return_Callback(hObject, eventdata, handles)
% hObject    handle to for_Return (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
       PIDCDTDS
       close( PIDCDTDS_PD)


% --------------------------------------------------------------------
function for_Clear_Callback(hObject, eventdata, handles)
% hObject    handle to for_Clear (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    set(handles.hn_gui,'String','');
    set(handles.hd_gui,'String','');
    set(handles.kp_gui,'String','');
    set(handles.kd_gui,'String','');
    set(handles.MaxDelayRange_gui,'String','');

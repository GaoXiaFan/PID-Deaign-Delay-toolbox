function strRootFW = GenerateCoefficient_FW_PI(hn,hd)
syms kp ki w real;
syms lambda;
Hn=poly2sym(hn,lambda);
Hd=poly2sym(hd,lambda);
Hn=subs(Hn,lambda,1i*w);
Hd=subs(Hd,lambda,1i*w);
F=(real(Hd*1i*w))^2+(imag(Hd*1i*w))^2-(real(Hn*(ki+kp*1i*w)))^2-(imag(Hn*(ki+kp*1i*w)))^2;
F=collect(F);
coeFw=poly_coeffs(F,'w');
coeFW=coeFw(1:2:end);
coeFW = fliplr(coeFW);
n=length(coeFW);

strRootFW = '                Wroot=roots([';
for i=1:1:n
    coeFWroot=coeFW(1,i);
    coeFWroot=char(coeFWroot);
    str = sprintf('(%s)\t',coeFWroot);   
    strRootFW = [strRootFW str];
end
str = ']);';
strRootFW = [strRootFW str];
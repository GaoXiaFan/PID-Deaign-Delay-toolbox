function Init_PI(hn,hd)
%�����ĸ������ļ�

strRootf = GenerateCoefficient_f_PI(hn,hd);%%lambdaroot=roots([])%%
p1 = mfilename('fullpath');%%�������н����˵��õ��ļ�������·�������ƣ��������ļ���չ����%%
location=strfind(p1,'\');%%��p1����������%%
p1=p1(1:location(end));
cd(p1);%%������һ��Ŀ¼%%
fidin1=fopen('PISubprogram_2.m','w+');
fprintf(fidin1,'%s',strRootf);
fclose(fidin1);

strRootFW = GenerateCoefficient_FW_PI(hn,hd);%%Wroot=roots([])%%
fidin1=fopen('PISubprogram_4.m','w+');
fprintf(fidin1,'%s',strRootFW);
fclose(fidin1);

[strHn,strHd] = GenerateHnHd_PI(hn,hd);
fidin1=fopen('PISubprogram_6.m','w+');
fprintf(fidin1,'%s',strHn);
fclose(fidin1);

fidin1=fopen('PISubprogram_7.m','w+');
fprintf(fidin1,'%s',strHd);
fclose(fidin1);


%1-20��
fidin1=fopen('PISubprogram_1.m','r+');
LineNumber=0;
newtline = [];
while ~feof(fidin1)
    tline=fgetl(fidin1);
    LineNumber=LineNumber+1;
    newtline{LineNumber}=tline;                                                                                                                                                                                                           
end
fclose(fidin1);

%21��
fidin1=fopen('PISubprogram_2.m','r+');%strRootf
while ~feof(fidin1)
    tline=fgetl(fidin1);
    LineNumber=LineNumber+1;
    newtline{LineNumber}=tline;                                                                                                                                                                                                         
end
fclose(fidin1);

%22-37��
fidin1=fopen('PISubprogram_3.m','r+');
while ~feof(fidin1)
    tline=fgetl(fidin1);
    LineNumber=LineNumber+1;
    newtline{LineNumber}=tline;                                                                                                                                                                                                         
end
fclose(fidin1);

%38��
fidin1=fopen('PISubprogram_4.m','r+');%strRootFW
while ~feof(fidin1)
    tline=fgetl(fidin1);
    LineNumber=LineNumber+1;
    newtline{LineNumber}=tline;
end
fclose(fidin1);

%39-60��
fidin1=fopen('PISubprogram_5.m','r+');
while ~feof(fidin1)
    tline=fgetl(fidin1);
    LineNumber=LineNumber+1;
    newtline{LineNumber}=tline;  
end
fclose(fidin1);

%61��
fidin1=fopen('PISubprogram_6.m','r+');%strHn
while ~feof(fidin1)
    tline=fgetl(fidin1);
    LineNumber=LineNumber+1;
    newtline{LineNumber}=tline;
end
fclose(fidin1);

%62hang
fidin1=fopen('PISubprogram_7.m','r+');%strHd
while ~feof(fidin1)
    tline=fgetl(fidin1);
    LineNumber=LineNumber+1;
    newtline{LineNumber}=tline;
end
fclose(fidin1);

%63-136��
fidin1=fopen('PISubprogram_8.m','r+');
while ~feof(fidin1)
    tline=fgetl(fidin1);
    LineNumber=LineNumber+1;
    newtline{LineNumber}=tline;
end
fclose(fidin1);


%������д����ʽ�򿪣�д�븲��ԭ��������
fidin1=fopen('PISubprogram.m','w+');
for j=1:1:LineNumber
    fprintf(fidin1,'%s\r\n',newtline{j});
end
fclose(fidin1);
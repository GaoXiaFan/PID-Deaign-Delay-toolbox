function [strHn,strHd] = GenerateHnHd_PI(hn,hd)
syms lambda;
Hn=poly2sym(hn,lambda);
Hd=poly2sym(hd,lambda);
Hn=char(Hn);
Hd=char(Hd);

str = ';';
strHn = '                        Hn=';
strHn = [strHn Hn];
strHn = [strHn str];

strHd = '                        Hd=';
strHd = [strHd Hd];
strHd = [strHd str];
function  [numberofStablilityIntervals, leftends, rightends]=FindingStabilityIntervals(CDsandPeriodsandDelta,numberofeffectiveWroots,NUDelayFree,MaxDelayRange)
 
% MaxDelayRange can not be too small (To ensure at least there are some effective CDs)

% MaxDelayRange=MaxDelayRange;

% NUDelayFree=NUDelayFree;

if numberofeffectiveWroots==1
    if NUDelayFree==0
        numberofStablilityIntervals=1;
        leftends=0;
        if CDsandPeriodsandDelta(1,1)<=MaxDelayRange
        rightends=CDsandPeriodsandDelta(1,1);
        else
            rightends=MaxDelayRange;
        end
    else
        numberofStablilityIntervals=0;
        leftends=[];
        rightends=[];        
    end
end

if  numberofeffectiveWroots>=2

CDsandDelta =[];

for p=1:1:numberofeffectiveWroots

    delay0=CDsandPeriodsandDelta(1,p);
    period0=CDsandPeriodsandDelta(2,p);
    
    numberofCDs=1+floor((MaxDelayRange-delay0)/period0);
    

deltaNU=CDsandPeriodsandDelta(3,p);
    
    for k=1:1:numberofCDs
    CDsandDelta=[CDsandDelta,[delay0+(k-1)*period0;deltaNU]];
    end
end

% CDsandDelta

try
firstrow=CDsandDelta(1,:);
secondrow=CDsandDelta(2,:);
[secondrow,order]=sort(secondrow,'descend');
firstrow=firstrow(order);
[firstrow,order]=sort(firstrow);
Sortsecondrow=secondrow(order);

structure=size(secondrow);
numberoftotalCDs=structure(1,2);
 

NU0=NUDelayFree;

if NU0==0
numberofStablilityIntervals=1;
leftends=0;
rightends=firstrow(1,1);
else
    numberofStablilityIntervals=0;
    leftends=[];
    rightends=[];
end


NUsequence=NU0;

for m=1:1:numberoftotalCDs   % include delay=0
    NU0=NU0+Sortsecondrow(1,m);
    NUsequence=[NUsequence,NU0];    
    if NU0==0
        numberofStablilityIntervals=numberofStablilityIntervals+1;
        leftends=[leftends,firstrow(1,m)];
        if m+1<=numberoftotalCDs
        rightends=[rightends, firstrow(1,m+1)];
        else
            rightends=[rightends,MaxDelayRange];
        end
    end
end
catch
      numberofStablilityIntervals=[];
      leftends=[];
      rightends=[];
end
end
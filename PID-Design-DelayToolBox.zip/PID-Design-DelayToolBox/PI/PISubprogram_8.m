                        z=-(Hd*lambda)/(Hn*(ki+kp*lambda));
                        criticalw=omega;
                        criticalZ=z;
                        angZ=angle(criticalZ);
                        if angZ<=0
                            tau0=-1*angZ/criticalw;
                            period=2*pi/criticalw;
                        end
                        if angZ>0
                            tau0=(2*pi-angZ)/criticalw; 
                            period=2*pi/criticalw;
                        end
                        if (-1)^t==-1
                            CDsandPeriodsandDelta=[CDsandPeriodsandDelta,[tau0;period;2]];
                        else
                            CDsandPeriodsandDelta=[CDsandPeriodsandDelta,[tau0;period;-2]];
                        end
                    end
                    [numberofStablilityIntervals, leftends, rightends]=FindingStabilityIntervals(CDsandPeriodsandDelta,numberofeffectiveWroots,NUDelayFree,MaxDelayRange);
                    if numberofStablilityIntervals>0
                        if NUDelayFree == 0
                            if rightends(1,1)>MaxDelayMargin
                                MaxDelayMargin=rightends(1,1);
                                MaxDelayMargin_kp=kp;
                                MaxDelayMargin_ki=ki; 
                            end
                        end
                        if numberofStablilityIntervals>MaxnumberofStabilityIntervals
                            MaxnumberofStabilityIntervals=numberofStablilityIntervals;
                        end
                        if rightends(1,numberofStablilityIntervals)>MaxGeneralizedDelayMargin
                            MaxGeneralizedDelayMargin=rightends(1,numberofStablilityIntervals);
                                MaxGeneralizedDelayMargin_kp=kp; 
                                MaxGeneralizedDelayMargin_ki=ki;
                        end
                        for i=1:1:numberofStablilityIntervals
                            plot3([kp kp],[ki ki],[leftends(1,i) rightends(1,i)],'color',col,'LineWidth',line)
                        end
                    end
                end
            end
     
    end
end


fprintf('Results of stability analysis by ''PID-Design-Delay''Toolbox:\n')
switch checkboxesinputvector(1)
    case 1
        fprintf('\t\t Maximal number of stability delay-intervals is %d.\n',MaxnumberofStabilityIntervals)
end
switch checkboxesinputvector(2)
    case 1
        fprintf('\t\t Maximal delay margin is %f.\n',MaxDelayMargin)
end
switch checkboxesinputvector(3)
    case 1
        fprintf('\t\t Maximal delay margin is found at (kp=%f,ki=%f).\n',MaxDelayMargin_kp,MaxDelayMargin_ki)
end
switch checkboxesinputvector(4)
    case 1
        fprintf('\t\t Maximal generalized delay margin is %f.\n',MaxGeneralizedDelayMargin)
end
switch checkboxesinputvector(5)
    case 1
        fprintf('\t\t Maximal generalized delay margin is found at (kp=%f,ki=%f).\n',MaxGeneralizedDelayMargin_kp,MaxGeneralizedDelayMargin_ki)
end
fprintf('\t\t For stability set, please see Figure ''Stability Set''.\n')
set(gcf,'Position',[50 200 500 400])
title('Stability set in (k_P, k_I, \tau)-space')
view(-133.6000,10.0000)
xlabel('k_P')
ylabel('k_I')
zlabel('\tau')
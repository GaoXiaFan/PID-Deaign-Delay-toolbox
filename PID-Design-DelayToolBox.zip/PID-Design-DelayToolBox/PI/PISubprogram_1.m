function PISubprogram(kp1,ki1,hn,hd,line,col,MaxDelayRange,sigma_precisionbound,checkboxesinputvector)

figure('NumberTitle', 'off', 'Name', 'Stability Set');
hold on

MaxnumberofStabilityIntervals=0;
MaxDelayMargin=0;
MaxGeneralizedDelayMargin=0;
MaxDelayMargin_kp=[];
MaxDelayMargin_ki=[];
MaxGeneralizedDelayMargin_kp=[];
MaxGeneralizedDelayMargin_ki=[];


for   kp=kp1
    for ki=ki1
        if( kp==0 && ki==0)
            continue;
        end
        
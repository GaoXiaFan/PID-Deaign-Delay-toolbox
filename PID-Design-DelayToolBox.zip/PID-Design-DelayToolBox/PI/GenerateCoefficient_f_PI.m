function strRootf = GenerateCoefficient_f_PI(hn,hd)
syms lambda;
Hn=poly2sym(hn,lambda);
Hd=poly2sym(hd,lambda);
syms kp ki real;
f=Hd*lambda+Hn*(ki+kp*lambda);
coef= poly_coeffs(f,'lambda');
coef = fliplr(coef);
n=length(coef);

strRootf = '        lambdaroot=roots([';
for i=1:1:n
    coefroot=coef(1,i);
    coefroot=char(coefroot);
    str = sprintf('(%s)\t',coefroot);
    strRootf = [strRootf str];
end

str = ']);';
strRootf = [strRootf str];
function varargout = PIDCDTDS(varargin)
clc;

disp('******** PID-Design-Delay Toolbox ********');
% PIDCDTDS MATLAB code for PIDCDTDS.fig
%      PIDCDTDS, by itself, creates a new PIDCDTDS or raises the existing
%      singleton*.
%
%      H = PIDCDTDS returns the handle to a new PIDCDTDS or the handle to
%      the existing singleton*.
%
%      PIDCDTDS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PIDCDTDS.M with the given input arguments.
%
%      PIDCDTDS('Property','Value',...) creates a new PIDCDTDS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before PIDCDTDS_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to PIDCDTDS_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help PIDCDTDS

% Last Modified by GUIDE v2.5 11-Nov-2018 12:38:51

% Begin initialization code - DO NOT EDIT

addpath(genpath(pwd));

gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @PIDCDTDS_OpeningFcn, ...
                   'gui_OutputFcn',  @PIDCDTDS_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before PIDCDTDS is made visible.
function PIDCDTDS_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to PIDCDTDS (see VARARGIN)

% Choose default command line output for PIDCDTDS
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
movegui( gcf, 'center' )
% UIWAIT makes PIDCDTDS wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = PIDCDTDS_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in Next_gui.
function Next_gui_Callback(hObject, eventdata, handles)
% hObject    handle to Next_gui (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

PI_Value=get(handles.PICDTDS_gui,'value');
PD_Value=get(handles.PDCDTDS_gui,'value');
PID_Value=get(handles.PIDCDTDS_gui,'value');
switch PI_Value
    case 1
        PIDCDTDS_PI
        close(PIDCDTDS)
end
switch PD_Value
    case 1
        PIDCDTDS_PD
        close(PIDCDTDS)
end
switch PID_Value
    case 1
        PIDCDTDS_PID
        close(PIDCDTDS)
end


% --------------------------------------------------------------------
function for_Help_ToolBox_Callback(hObject, eventdata, handles)
% hObject    handle to for_Help_ToolBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Help
